import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { notFound } from "next/navigation";
function Badge({ s }:{ s:any }){
  const m:any={AVAILABLE:{t:"Disponible",bg:"#e9f9ef",c:"#0a7a2a"},RESERVED_PENDING:{t:"Reservado (Pend.)",bg:"#fff6e5",c:"#a66300"},RESERVED_CONFIRMED:{t:"Reservado",bg:"#e5f0ff",c:"#1b51a8"},SOLD:{t:"Vendido",bg:"#f1f3f6",c:"#666"}};
  const v=m[s]||m.AVAILABLE; return <span style={{background:v.bg,color:v.c,padding:"4px 8px",borderRadius:8,fontSize:12}}>{v.t}</span>
}
export default async function Project({params}:{params:{id:string}}){
  const p = await prisma.project.findUnique({ where:{id:params.id}, include:{units:true} }); if(!p) return notFound();
  return (
    <main style={{maxWidth:1100, margin:"40px auto", padding:"0 16px"}}>
      <div style={{background:"#fff",borderRadius:12,border:"1px solid #e9eef5",overflow:"hidden"}}>
        <div style={{height:240,background:"#eef1f6",display:"grid",placeItems:"center"}}>{p.coverUrl? <img src={p.coverUrl}/>:"Sin imagen"}</div>
        <div style={{padding:16}}><h1>{p.name}</h1><div>{p.address} · {p.city}, {p.country}</div>
          <div style={{opacity:.8,fontSize:13}}>Entrega: {new Date(p.deliveryDate).toLocaleDateString("es-CL")}</div></div>
      </div>
      <div style={{background:"#fff",borderRadius:12,border:"1px solid #e9eef5",marginTop:16}}>
        <div style={{padding:"14px 16px",borderBottom:"1px solid #e9eef5",fontWeight:700}}>Stock</div>
        <div style={{display:"grid",gridTemplateColumns:"100px 120px 80px 140px 140px 160px",fontSize:14,fontWeight:600,padding:"10px 16px",background:"#fafbfe"}}><div>Depto</div><div>Tipología</div><div>m²</div><div>Precio</div><div>Estado</div><div>Acción</div></div>
        {p.units.map(u=>(
          <div key={u.id} style={{display:"grid",gridTemplateColumns:"100px 120px 80px 140px 140px 160px",padding:"10px 16px",borderTop:"1px solid #f0f2f6",alignItems:"center"}}>
            <div>{u.code}</div><div>{u.typology}</div><div>{u.m2}</div>
            <div style={{fontWeight:700}}>{u.currency} {u.price.toLocaleString("en-US")}</div>
            <div><Badge s={u.status} /></div>
            <div>{u.status==="AVAILABLE"? <Link href={`/unit/${u.id}`} style={{border:"1px solid #111",borderRadius:8,padding:"6px 10px"}}>Cotizar</Link> : <span style={{opacity:.6}}>—</span>}</div>
          </div>))}
      </div>
    </main>
  );
}
