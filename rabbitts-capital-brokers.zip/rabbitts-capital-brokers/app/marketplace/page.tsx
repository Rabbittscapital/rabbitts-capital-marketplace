import { prisma } from "@/lib/prisma";
import Link from "next/link";
function f(d:Date){ return new Date(d).toLocaleDateString("es-CL"); }
export default async function Marketplace(){
  const projects = await prisma.project.findMany({ orderBy:{createdAt:"desc"} });
  return (
    <main style={{maxWidth:1100, margin:"40px auto", padding:"0 16px"}}>
      <h1 style={{marginBottom:16}}>Catálogo de Proyectos</h1>
      <div style={{display:"grid", gap:16, gridTemplateColumns:"repeat(auto-fill, minmax(280px,1fr))"}}>
        {projects.map(p=>(
          <Link href={`/project/${p.id}`} key={p.id}
            style={{background:"#fff",border:"1px solid #e9eef5",borderRadius:12,overflow:"hidden",color:"#111"}}>
            <div style={{height:160, background:"#eef1f6", display:"grid", placeItems:"center"}}>
              {p.coverUrl ? <img src={p.coverUrl} style={{width:"100%",height:"100%",objectFit:"cover"}}/> : "Sin imagen"}
            </div>
            <div style={{padding:14}}>
              <div style={{fontWeight:700}}>{p.name}</div>
              <div style={{fontSize:13,opacity:.8}}>{p.city}, {p.country}</div>
              <div style={{fontSize:13,marginTop:6}}>Entrega: {f(p.deliveryDate as any)}</div>
              <div style={{marginTop:10}}>
                <span style={{border:"1px solid #111",borderRadius:8,padding:"6px 10px",display:"inline-block"}}>Ver proyecto</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
