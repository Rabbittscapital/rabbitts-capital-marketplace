import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import QuoteForm from "./quote-form";
export default async function UnitPage({params}:{params:{id:string}}){
  const unit = await prisma.unit.findUnique({ where:{id:params.id}, include:{ project:true, quotes:{ include:{ broker:true }, orderBy:{ createdAt:"desc" } } } });
  if(!unit) return notFound();
  return (
    <main style={{maxWidth:1100, margin:"40px auto", padding:"0 16px"}}>
      <div style={{display:"grid",gap:16,gridTemplateColumns:"1.1fr .9fr"}}>
        <div style={{background:"#fff",border:"1px solid #e9eef5",borderRadius:12,padding:16}}>
          <h1>Depto {unit.code} – {unit.project.name}</h1>
          <div style={{opacity:.8,fontSize:13,marginBottom:8}}>{unit.project.address} · {unit.project.city}, {unit.project.country}</div>
          <div><b>Tipología:</b> {unit.typology} · <b>m²:</b> {unit.m2} · <b>D:</b> {unit.bedrooms} · <b>B:</b> {unit.bathrooms}</div>
          <div style={{fontSize:22,fontWeight:800,marginTop:10}}>{unit.currency} {unit.price.toLocaleString("en-US")}</div>
          <div style={{fontSize:12,opacity:.7}}>* Moneda mostrada tal como fue listada por el desarrollador.</div>
          <h3 style={{marginTop:20}}>Cotizaciones recientes</h3>
          <ul style={{fontSize:14,lineHeight:"22px"}}>
            {unit.quotes.map(q=><li key={q.id}>{new Date(q.createdAt).toLocaleString("es-CL")} – {q.broker.name}: {q.downPaymentPct}% / {q.installments} · Pie {unit.currency} {q.calculatedDownPayment.toLocaleString("en-US")} · Cuota {unit.currency} {q.installmentValue.toLocaleString("en-US")} {q.pdfUrl? (<a href={q.pdfUrl} style={{marginLeft:8}}>PDF</a>):null}</li>)}
            {unit.quotes.length===0 && <li>Sin cotizaciones.</li>}
          </ul>
        </div>
        <QuoteForm unitId={unit.id} unitPrice={unit.price} currency={unit.currency as any} />
      </div>
    </main>
  );
}
