"use client";
import { useState } from "react";
export default function QuoteForm({ unitId, unitPrice, currency }:{ unitId:string; unitPrice:number; currency:"USD"|"UF" }){
  const [pct,setPct]=useState(20); const [inst,setInst]=useState(24); const [qid,setQid]=useState<string>("");
  const down = Math.round(unitPrice*(pct/100)); const installment = Math.max(1,Math.round(down/inst));
  async function saveQuote(){ const r=await fetch("/api/quote/create",{method:"POST",headers:{ "Content-Type":"application/json"},body:JSON.stringify({unitId,downPaymentPct:pct,installments:inst})}); const d=await r.json(); setQid(d.id); }
  async function upload(e:React.FormEvent<HTMLFormElement>){ e.preventDefault(); if(!qid){alert("Guarda la cotización primero");return;} const fd=new FormData(e.currentTarget); fd.append("quoteId",qid); const r=await fetch("/api/receipt/upload",{method:"POST",body:fd}); alert(r.ok?"Comprobante subido. Reservado (Pendiente).":"Error al subir"); (e.currentTarget as any).reset(); }
  return (<div style={{background:"#fff",border:"1px solid #e9eef5",borderRadius:12,padding:16}}>
    <h2>Cotizador</h2>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
      <div><label>% Pie</label><select value={pct} onChange={e=>setPct(parseInt(e.target.value))} style={{width:"100%",marginTop:6}}>{[10,15,20,30].map(v=><option key={v} value={v}>{v}%</option>)}</select></div>
      <div><label>Cuotas</label><select value={inst} onChange={e=>setInst(parseInt(e.target.value))} style={{width:"100%",marginTop:6}}>{[12,24,36,48].map(v=><option key={v} value={v}>{v}</option>)}</select></div>
    </div>
    <div style={{marginTop:12,background:"#fafbfe",padding:12,borderRadius:8}}>
      <div><b>Pie total:</b> {currency} {down.toLocaleString("en-US")}</div>
      <div><b>Cuota del pie:</b> {currency} {installment.toLocaleString("en-US")} × {inst} meses</div>
    </div>
    <div style={{display:"flex",gap:8,marginTop:12}}>
      <button onClick={saveQuote} style={{border:"1px solid #111",borderRadius:8,padding:"8px 12px"}}>Guardar & generar PDF</button>
      {qid && <a href={`/api/quote/${qid}/pdf`} style={{border:"1px solid #111",borderRadius:8,padding:"8px 12px"}}>Descargar PDF</a>}
    </div>
    <form onSubmit={upload} style={{marginTop:16,display:"grid",gap:8}}>
      <label>Subir comprobante (PDF/JPG/PNG)</label>
      <input name="file" type="file" accept=".pdf,image/*" required />
      <input name="note" type="text" placeholder="Nota (opcional)" />
      <button type="submit" style={{border:"1px solid #111",borderRadius:8,padding:"8px 12px"}}>Subir comprobante</button>
    </form></div>);
}
