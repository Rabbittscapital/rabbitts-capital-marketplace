import { prisma } from "@/lib/prisma"; import { getServerSession } from "next-auth"; import { authOptions } from "@/lib/auth";
export async function POST(req:Request){ const s=await getServerSession(authOptions); if(!s?.user) return new Response("Unauthorized",{status:401});
  const fd=await req.formData(); const file=fd.get("file") as File|null; const note=(fd.get("note") as string)||""; const quoteId=(fd.get("quoteId") as string)||""; if(!file||!quoteId) return new Response("Missing",{status:400});
  const q=await prisma.quote.findUnique({where:{id:quoteId},include:{unit:true}}); if(!q) return new Response("Quote not found",{status:404});
  const buf=Buffer.from(await file.arrayBuffer()); const b64=buf.toString("base64");
  await prisma.receipt.create({data:{quoteId:q.id,fileName:file.name,mimeType:file.type||"application/octet-stream",contentB64:b64,note}});
  await prisma.unit.update({where:{id:q.unitId},data:{status:"RESERVED_PENDING"}}); return Response.json({ok:true}); }
