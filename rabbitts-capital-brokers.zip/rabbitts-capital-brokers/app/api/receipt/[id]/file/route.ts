import { prisma } from "@/lib/prisma";
export async function GET(_:Request,{params}:{params:{id:string}}){ const r=await prisma.receipt.findUnique({where:{id:params.id}}); if(!r) return new Response("Not found",{status:404}); const buf=Buffer.from(r.contentB64,"base64"); return new Response(buf,{headers:{ "Content-Type":r.mimeType,"Content-Disposition":`inline; filename=${r.fileName}` }}); }
