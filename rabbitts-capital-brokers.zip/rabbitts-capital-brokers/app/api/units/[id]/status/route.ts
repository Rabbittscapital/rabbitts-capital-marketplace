import { getServerSession } from "next-auth"; import { authOptions } from "@/lib/auth"; import { prisma } from "@/lib/prisma";
export async function POST(req:Request,{params}:{params:{id:string}}){ const s=await getServerSession(authOptions); if((s as any)?.role!=="ADMIN") return new Response("Forbidden",{status:403});
  const url=new URL(req.url); const action=url.searchParams.get("action");
  if(action==="approve"){ await prisma.unit.update({where:{id:params.id},data:{status:"RESERVED_CONFIRMED"}}); return Response.json({ok:true}); }
  if(action==="reject"){ const qs=await prisma.quote.findMany({where:{unitId:params.id},include:{receipt:true},orderBy:{createdAt:"desc"}}); const q=qs.find(x=>x.receipt); if(q?.receipt) await prisma.receipt.delete({where:{id:q.receipt.id}}); await prisma.unit.update({where:{id:params.id},data:{status:"AVAILABLE"}}); return Response.json({ok:true}); }
  if(action==="sold"){ await prisma.unit.update({where:{id:params.id},data:{status:"SOLD"}}); return Response.json({ok:true}); }
  return new Response("Bad request",{status:400}); }
