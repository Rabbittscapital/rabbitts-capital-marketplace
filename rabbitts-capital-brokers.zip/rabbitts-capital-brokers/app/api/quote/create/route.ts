import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
export async function POST(req:Request){ const s=await getServerSession(authOptions); if(!s?.user?.email) return new Response("Unauthorized",{status:401});
  const {unitId,downPaymentPct,installments}=await req.json(); const u=await prisma.unit.findUnique({where:{id:unitId}}); if(!u||u.status!=="AVAILABLE") return new Response("Unit not available",{status:400});
  const broker=await prisma.user.findUnique({where:{email:s.user.email}}); if(!broker) return new Response("No user",{status:400});
  const down=Math.round(u.price*(downPaymentPct/100)); const inst=Math.max(1,Math.round(down/installments));
  const q=await prisma.quote.create({data:{unitId,brokerId:broker.id,downPaymentPct,installments,calculatedDownPayment:down,installmentValue:inst}}); return Response.json({id:q.id}); }
