import PDFDocument from "pdfkit"; import { prisma } from "@/lib/prisma";
export async function GET(_:Request,{params}:{params:{id:string}}){
  const q=await prisma.quote.findUnique({where:{id:params.id},include:{unit:{include:{project:true}},broker:true}}); if(!q) return new Response("Not found",{status:404});
  const doc=new PDFDocument({size:"A4",margin:50}); const chunks:any[]=[]; doc.on("data",(c)=>chunks.push(c)); const done=new Promise<Buffer>(res=>doc.on("end",()=>res(Buffer.concat(chunks))));
  doc.fontSize(18).text("Rabbitts Capital – Cotización"); doc.moveDown();
  doc.fontSize(12).text(`Proyecto: ${q.unit.project.name}`); doc.text(`Dirección: ${q.unit.project.address}, ${q.unit.project.city}, ${q.unit.project.country}`);
  doc.text(`Unidad: ${q.unit.code} · Tipología: ${q.unit.typology} · m²: ${q.unit.m2}`); doc.text(`Precio: ${q.unit.currency} ${q.unit.price.toLocaleString("en-US")}`); doc.moveDown();
  doc.text(`Broker: ${q.broker.name} (${q.broker.email})`); doc.text(`Fecha: ${new Date(q.createdAt).toLocaleString("es-CL")}`); doc.moveDown();
  doc.text(`Pie: ${q.downPaymentPct}%  |  Cuotas: ${q.installments}`); doc.text(`Monto Pie: ${q.unit.currency} ${q.calculatedDownPayment.toLocaleString("en-US")}`); doc.text(`Cuota del Pie: ${q.unit.currency} ${q.installmentValue.toLocaleString("en-US")} x ${q.installments} meses`);
  doc.moveDown(); doc.fontSize(10).fillColor("#555").text("La moneda se muestra tal como fue listada por el desarrollador."); doc.end(); const pdf=await done;
  return new Response(pdf,{status:200,headers:{ "Content-Type":"application/pdf","Content-Disposition":`inline; filename=cotizacion-${q.id}.pdf` }}); }
