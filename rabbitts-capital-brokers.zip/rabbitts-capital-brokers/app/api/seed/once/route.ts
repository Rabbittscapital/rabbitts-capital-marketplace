import { prisma } from "@/lib/prisma";
export async function POST(){
  const pass = "$2b$10$B3U2ok7fT3aq4odl20W18uoz.FXx0g3ZP2x1y3dTu1aYcY1M4c0XO";
  await prisma.user.upsert({ where:{email:"admin@rabbitts.capital"}, update:{}, create:{ name:"Admin", email:"admin@rabbitts.capital", passwordHash:pass, role:"ADMIN" } });
  await prisma.user.upsert({ where:{email:"broker@rabbitts.capital"}, update:{}, create:{ name:"Broker", email:"broker@rabbitts.capital", passwordHash:pass, role:"BROKER" } });
  const miami = await prisma.project.upsert({ where:{name:"Condo Miami Bayside"}, update:{}, create:{ name:"Condo Miami Bayside", coverUrl:"", address:"123 Bayside Ave", city:"Miami", country:"USA", deliveryDate:new Date(Date.now()+1000*60*60*24*180) }});
  const nunoa = await prisma.project.upsert({ where:{name:"Edificio Ñuñoa Activa"}, update:{}, create:{ name:"Edificio Ñuñoa Activa", coverUrl:"", address:"Av. Irarrázaval 1234", city:"Santiago", country:"Chile", deliveryDate:new Date(Date.now()+1000*60*60*24*365) }});
  await prisma.unit.createMany({ data:[
    { projectId: miami.id, code:"101", typology:"1D1B", m2:50, bedrooms:1, bathrooms:1, price:250000, currency:"USD", status:"AVAILABLE" },
    { projectId: miami.id, code:"102", typology:"2D1B", m2:65, bedrooms:2, bathrooms:1, price:280000, currency:"USD", status:"AVAILABLE" },
    { projectId: miami.id, code:"103", typology:"2D2B", m2:78, bedrooms:2, bathrooms:2, price:0, currency:"USD", status:"SOLD" },
    { projectId: nunoa.id, code:"201", typology:"1D1B", m2:42, bedrooms:1, bathrooms:1, price:3800, currency:"UF", status:"AVAILABLE" },
    { projectId: nunoa.id, code:"202", typology:"2D1B", m2:55, bedrooms:2, bathrooms:1, price:4700, currency:"UF", status:"RESERVED_CONFIRMED" },
    { projectId: nunoa.id, code:"203", typology:"2D2B", m2:68, bedrooms:2, bathrooms:2, price:5200, currency:"UF", status:"AVAILABLE" }
  ]});
  return Response.json({ ok:true });
}
